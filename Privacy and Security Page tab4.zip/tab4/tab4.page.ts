import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule, AlertController } from '@ionic/angular';
import { ThemeService } from '../services/theme.service';

@Component({
  selector: 'app-tab4',
  templateUrl: './tab4.page.html',
  styleUrls: ['./tab4.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonicModule
  ]
})
export class Tab4Page {
  isDarkMode = false;

  constructor(private themeService: ThemeService, private alertController: AlertController) {
    this.isDarkMode = this.themeService.getIsDarkMode();
  }

  //帮助页面
  async showHelp() {
    const alert = await this.alertController.create({
      header: 'Privacy & Security Help',
      message: '<b>Data Collection:</b> We only collect data necessary for inventory management<br><br><b>Data Usage:</b> Your data is used solely for inventory purposes<br><br><b>Data Storage:</b> All data is securely stored on protected servers<br><br><b>API Security:</b> All communications use HTTPS encryption',
      cssClass: 'custom-alert',
      buttons: ['OK']
    });
    await alert.present();
  }

  toggleDarkMode() {
    this.themeService.toggleDarkMode();
    this.isDarkMode = this.themeService.getIsDarkMode();
  }
}
